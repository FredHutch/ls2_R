# *Snakemake workflow for ichorCNA*

## Description
This workflow will run the ichorCNA pipeline for a , starting from the BAM files and generating ichorCNA outputs. 

**Please see the [ichorCNA snakemake wiki page](https://github.com/broadinstitute/ichorCNA/wiki/SnakeMake-pipeline-for-ichorCNA) for more details**
